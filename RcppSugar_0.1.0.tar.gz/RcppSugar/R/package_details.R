#' RcppSugar
#' 
#' This package exposes directly the Rcpp 'Sugar' functions available, and also
#' provides some light checking of types in R.
#' 
#' @name RcppSugar
#' @docType package
#' @useDynLib RcppSugar
NULL